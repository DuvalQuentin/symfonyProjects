Insert into dbpremiersymfo40.employe (nom, salaire) values
("Martin", 10000.00),
("Dupont", 23000.00),
("Russot", 45600.00),
("Delevoy", 12000.00),
("Dumans", 34000.00)
;

